package ma.ac.esi.referentielCompetences.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectBd {

    private static final String jdbcUrl = "jdbc:mysql://localhost:3306/connect";
    private static final String user = "root";
    private static final String password = "minamina";

    public Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(jdbcUrl, user, password);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Erreur lors du chargement du pilote JDBC.", e);
        }
    }


    public User findUser(String login, String password) {
        System.out.println("Tentative de connexion à la base de données.");

        try (Connection connection = getConnection()) {
            System.out.println("Connexion à la base de données établie.");

            String query = "SELECT * FROM Users WHERE login = ? AND password = ?";
            System.out.println("Requête SQL : " + query);

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, login);
                preparedStatement.setString(2, password);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String foundLogin = resultSet.getString("login");
                        String foundPassword = resultSet.getString("password");

                        System.out.println("Utilisateur trouvé - Login : " + foundLogin + ", Password : " + foundPassword);

                        return new User(foundLogin, foundPassword);
                    } else {
                        System.out.println("Aucun utilisateur trouvé.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Code d'erreur SQL : " + e.getErrorCode());
            System.out.println("Message d'erreur SQL : " + e.getMessage());
            System.out.println("État SQL : " + e.getSQLState());

          
            if (e.getMessage().toLowerCase().contains("communications link failure")) {
                System.out.println("Erreur de connexion à la base de données. Vérifiez la configuration de la base de données.");
            } else {
                System.out.println("Erreur d'exécution de la requête SQL. Vérifiez la syntaxe de votre requête et les données de la table.");
            }
        }

        return null;
    }

}