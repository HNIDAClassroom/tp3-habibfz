package ma.ac.esi.referentielCompetences.controleur;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ma.ac.esi.referentielCompetences.model.ConnectBd;
import ma.ac.esi.referentielCompetences.model.User;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ServletController
 */
public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		        // Récupération des paramètres de la requête
		        String login = request.getParameter("login");
		        String password = request.getParameter("password");

		        // Vérification que les paramètres ne sont pas nuls
		        if (login == null || password == null) {
		            // Gérer le cas où les paramètres sont nuls
		            response.getWriter().println("Veuillez saisir un login et un mot de passe.");
		            return;
		        }

		        // Appel de la méthode findUser de la classe ConnectBd pour récupérer l'utilisateur
		        ConnectBd connectBd = new ConnectBd();
		        User user = connectBd.findUser(login, password);

		        // Vérification si l'utilisateur existe
		        if (user != null) {
		            // Affichage du message de bienvenue avec le login de l'utilisateur
		            response.setContentType("text/html");
		            PrintWriter out = response.getWriter();
		            out.println("<html>");
		            out.println("<body>");
		            out.println("<h1>Bienvenue, " + user.getLogin() + "!</h1>");
		            out.println("</body>");
		            out.println("</html>");
		        } else {
		            // Gérer le cas où l'utilisateur n'existe pas
		            response.getWriter().println("Utilisateur non trouvé. Veuillez vérifier vos identifiants.");
		        }
		    }
		
	}


